Quick start:
Load package
Add your first cheat:
(cheatsheet-add :group 'Common
                :key "C-x C-c"
                :description "leave Emacs.")
Run (cheatsheet-show) and enjoy looking at your own Emacs cheatsheet.
